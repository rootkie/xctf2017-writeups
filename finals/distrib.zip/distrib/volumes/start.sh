#!/bin/bash

echo "Starting challenge ${CYCLE_ID}..."
exec /round00/${CYCLE_ID}/run_exploitable.sh
